<li><a href="#">Home</a></li>
<li><a href="#service">Dienstleistungen</a></li>
<li><a href="#clients">Kunden</a></li>
<li><a href="#team">Team</a></li>
<li><a href="#contact">Kontakt</a></li>