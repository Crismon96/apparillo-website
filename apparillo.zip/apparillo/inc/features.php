<div class="features">
    <div class="container">
        <div class="row">
            <div class="six columns">
                <div>
                    <div class="feature-icon">
                        <i class="fa fa-id-card-o" aria-hidden="true"></i>
                    </div>
                    <div class="feature-text">  
                        <h5>Branding & Identity</h5>
                        <p>
                            Ohne Marketing kein Business. In Zukunft gilt das noch mehr als heute. Digitales Marketing muss aber keineswegs kompliziert sein, sondern kann auch ganz automatisiert ablaufen.
                        </p>
                    </div>
                </div>
                <div>
                    <div class="feature-icon">
                        <i class="fa fa-mobile" aria-hidden="true"></i>
                    </div>
                    <div class="feature-text">  
                        <h5>Mobile App Development</h5>
                        <p>
                            Mit Swift entwickeln wir hochkarätige iOS-Apps nach eigenem Design und Ihren Vorstellungen.
                        </p>
                    </div>
                </div>
                <div>
                    <div class="feature-icon">
                        <i class="fa fa-star" aria-hidden="true"></i>
                    </div>
                    <div class="feature-text">  
                        <h5>UI / UX</h5>
                        <p>
                            Es kann so einfach sein ein schnelles, aber leistungsfähiges individuelles GUI mit QT aufzubauen. Sparen Sie sich Ärger und Zeit.
                        </p>
                    </div>
                </div>
            </div>
            <div class="six columns">
                <div>
                    <div class="feature-icon">
                        <i class="fa fa-window-restore" aria-hidden="true"></i>
                    </div>
                    <div class="feature-text">  
                        <h5>Web & Graphic Design</h5>
                        <p>
                            Eine individuelle handgefertigte Website mit dem persönlichen Schliff oder eine ebendso qualitativ hochwertige, aber einfachere Lösung mithilfe des CMS Wordpress. 
                            Sie haben die Wahl.
                        </p>
                    </div>
                </div>
                <div>
                    <div class="feature-icon">
                        <i class="fa fa-video-camera" aria-hidden="true"></i>
                    </div>
                    <div class="feature-text">  
                        <h5>Animations</h5>
                        <p>
                            Ob kurze Videosequenzen oder detailgetreue Bildbearbeitung mit dem Tool GIMP. Alles kein Problem. 
                        </p>
                    </div>
                </div>
                <div>
                    <div class="feature-icon">
                        <i class="fa fa-photo" aria-hidden="true"></i>
                    </div>
                    <div class="feature-text">  
                        <h5>Photography</h5>
                        <p>
                            Jeder Moment ist einzigartig und sollte so geschätzt werden. Unseren ausgezeichneten Partnern ist es möglich diese Momente einzufangen. 
                            Das perfekte Porträt oder die atemberaubendsten Landschaftsaufnahmen sind möglich und können durch uns im WWW angemessen in Szene gesetzt werden.  
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>