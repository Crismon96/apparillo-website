<div class="service" id="service">
    <div class="container">
        <div class="row">
            <div class="eight columns">
                <h1 class="service-title">Web <strong>Development</strong></h1>
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod 
                    tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, 
                    quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo 
                    consequat. 
                </p>
                <p>
                    Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia
                    deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur
                    adipiscing elit.
                </p>
            </div>
            <div class="four columns">
                <div class="service-icon">
                    <i class="fa fa-html5" aria-hidden="true"></i>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="service service-gray">
    <div class="container">
        <div class="row">
            <div class="four columns">
                <div class="service-icon">
                    <i class="fa fa-id-card-o" aria-hidden="true"></i>
                </div>
            </div>
            <div class="eight columns">
                <h1 class="service-title">Identity <strong>Branding</strong></h1>
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod 
                    tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, 
                    quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo 
                    consequat. 
                </p>
                <p>
                    Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia
                    deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur
                    adipiscing elit.
                </p>
            </div>
        </div>
    </div>
</div>