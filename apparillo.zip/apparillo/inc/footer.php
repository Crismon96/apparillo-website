<div class="footer">
    <div class="container">
        <hr class="footer-hr" />
        <p>Umgesetzt nach Udemy. Diese Website stellt nur eine Vorlage dar. <strong><a href="#">Nach oben</a></strong></p>
    </div>
</div>